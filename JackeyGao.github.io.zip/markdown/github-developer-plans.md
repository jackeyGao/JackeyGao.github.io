title: 开了Github个人会员
date: 2018-12-20 14:59:30
---


终于下定决心开了 Github developer plan， 把一些不适合开放的项目 push 了上去.

一般对我来说 这些项目都放在了国内的 Coding 或者 Gitee 上， 但我太不喜欢这两个社区了， 尤其是 OSChina. 所以造成这些项目基本不更新， 甚至觉得这些项目很混乱。 


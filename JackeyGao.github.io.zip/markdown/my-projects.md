title: 我做的一些项目
date: 2018-10-16 01:01:11
---


![](/uploads/images/my-projects.jpeg "cover")

工作五年， 从事运维开发三年， 我做了很多项目， 在此记录下。

> 个人项目

- [requestMeta](https://github.com/jackeyGao/requestMeta)
- [cornus]()
- [yanyue](#)
- [chinese-poetry](https://github.com/chinese-poetry/chinese-poetry)
- [poetry-calendar](https://github.com/chinese-poetry/poetry-calendar)
- [jianshuHot](https://github.com/jackeyGao/jianshuHot)
- [JackeyGao.github.io.bakup](https://github.com/jackeyGao/JackeyGao.github.io.bakup)
- [django-vuejs](https://github.com/jackeyGao/django-vuejs)
- [WeUnsplash](https://github.com/jackeyGao/WeUnsplash)
- [heroText](https://github.com/jackeyGao/heroText)
- [csvSQL](https://github.com/jackeyGao/csvSQL)
- [CMDAnalysis](https://github.com/jackeyGao/CMDAnalysis)
- [markblog](https://github.com/jackeyGao/markblog)

> *Teambition* 2017.03 - 至今

- Vision MongoDB 数据库中间件
- [Hawkeye](/words/hawkeye.html) 监控图表聚合系统
- Unspace 配置管理系统
- Ultron 运维信息聚合中心
- Ultron-message 一个面向后端开发者接入 Ultron 的 UDP 服务.
- Ultron-jenkins 发布系统(基于 Teambition 任务和 Jenkins 的结合)
- Cable 基于 Ansibile 的运维管理平台及作业平台.(Docible 2.0)
- SSO 运维系统单点登录系统
- Banshee 有向监控系统
- Nova 私有部署页面化部署系统


> *格瓦拉生活网* 2016.03 - 2017.03

- Docible 基于 Ansible 运维管理平台
- AlertMiddleware 监控信息聚合调度器中间件
- NGraph 报表系统 v2


> *数云* 2012.09 - 2016.03

- gungnir 一个监控中心化平台
- report 监控报表系统
- deploy 部署系统
- 发布系统
- [dbInterface](https://github.com/jackeyGao/dbInterface)  是一个基于Django 通过REST接口来创建table， 并通过接口的方式对table进行数据增删改查.
- [bubustatus](https://github.com/jackeyGao/bubustatus) 运维步骤状态服务端


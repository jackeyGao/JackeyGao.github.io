title: Python 介绍PPT
date: 2016-05-20 18:03:33
tags:
- Python
- PPT
---

## [Python语法介绍的入门文档](/uploads/docs/python-introction.pdf)

- 背景
- 语法
- 数据类型
- 操作符
- 控制流
- 函数
- 类
- 工具推荐

## [Python进阶文档](/uploads/docs/python-intermediate.pdf)

- *args 和 **kwargs 应用场景
- 闭包和装饰器
- Lambda
- Map & Filter
- 三元运算符
- Collections
- 对象自省
- 一行式 
- 上下文管理器
- 推荐学习网站和资料

## [Django 学习](/uploads/docs/django-learn.pdf)

- Django 介绍安装
- Project 和 APP概念
- Model, View, Template(MVT)
- Django ORM

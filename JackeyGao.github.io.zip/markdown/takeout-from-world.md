title: Takeout from world
date: 2017-07-18 12:31:43
set: 瞎JB扯淡
---

不知道为什么总感觉这一天会来的, 而且快要临头了。

Google全家数据

[https://takeout.google.com/settings/takeout](https://takeout.google.com/settings/takeout) 打包后下载.


Gmail 设置转发mail。

[https://mail.google.com/mail/u/0/#settings/fwdandpop](https://mail.google.com/mail/u/0/#settings/fwdandpop)


Twitter

[https://twitter.com/settings/your_twitter_data](https://twitter.com/settings/your_twitter_data)

